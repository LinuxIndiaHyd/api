import os
import subprocess
import json
import boto3

def assume_aws_role(role_arn, region):
    # Assume AWS Role
    assume_cmd = f"aws sts assume-role --role-arn {role_arn} --role-session-name awscli-session --duration-seconds 3600"
    result = subprocess.run(assume_cmd, shell=True, stdout=subprocess.PIPE)
    credentials = json.loads(result.stdout.decode())

    # Export assumed role credentials as environment variables
    os.environ["AWS_ACCESS_KEY_ID"] = credentials["Credentials"]["AccessKeyId"]
    os.environ["AWS_SECRET_ACCESS_KEY"] = credentials["Credentials"]["SecretAccessKey"]
    os.environ["AWS_SESSION_TOKEN"] = credentials["Credentials"]["SessionToken"]

    # Set region for boto3 clients
    os.environ["AWS_DEFAULT_REGION"] = region

def accept_portfolio(portfolio_id, role_arn, region):
    if not role_arn or not region or not portfolio_id:
        print("Role ARN, region, or portfolio ID not found. Exiting.")
        return

    assume_aws_role(role_arn, region)

    # Accept the portfolio using AWS SDK (boto3)
    client = boto3.client('servicecatalog')
    try:
        response = client.accept_portfolio_share(
            PortfolioId=portfolio_id
        )
        print("Portfolio accepted successfully!")
    except Exception as e:
        print(f"Failed to accept portfolio: {str(e)}")

if __name__ == "__main__":
    # Get the values passed from Terraform environment variables
    portfolio_id = os.getenv("PORTFOLIO_ID")
    role_arn = os.getenv("ROLE_ARN")
    region = os.getenv("AWS_DEFAULT_REGION")

    accept_portfolio(portfolio_id, role_arn, region)
